import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { message, location } = await request.json()

    const chatbotResponse = await fetch("https://your-backend-url.com/api/chatbot/message", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        // Add your API key here if required
        // 'Authorization': 'Bearer YOUR_API_KEY'
      },
      body: JSON.stringify({
        message,
        user_id: "user_123", // You can generate or manage user IDs as needed
        location: location
          ? {
              latitude: location.lat,
              longitude: location.lng,
            }
          : undefined,
      }),
    })

    if (!chatbotResponse.ok) {
      throw new Error("Failed to get response from chatbot API")
    }

    const data = await chatbotResponse.json()

    let places = null
    if (data.places && location) {
      try {
        const placesResponse = await fetch("https://your-backend-url.com/api/places/nearest", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            latitude: location.lat,
            longitude: location.lng,
            radius: 1000, // 1km radius
            limit: 5,
          }),
        })

        if (placesResponse.ok) {
          const placesData = await placesResponse.json()
          places = placesData.places
        }
      } catch (error) {
        console.error("Error fetching places:", error)
      }
    }

    return NextResponse.json({
      response: data.response,
      places: places,
    })
  } catch (error) {
    console.error("Error in chat API:", error)
    return NextResponse.json({ error: "Failed to process message" }, { status: 500 })
  }
}
